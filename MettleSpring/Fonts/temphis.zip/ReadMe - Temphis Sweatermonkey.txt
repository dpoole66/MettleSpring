TEMPHIS SWEATERMONKEY
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

As you might have noticed, my fontmaking efforts this week have been focused on the completion of a spiffy commercial project, the Temphis Runes. So, to celebrate the release of the Runes, here's a freeware addition to the Temphis family not found in the commercial set. Snag it now before it vanishes into the mists!

"Temphis Sweatermonkey" is an oddball sort of font, because it has a very modern look applied to letterforms meant for an (admittedly lighthearted) medieval fantasy world. It would, however, make a very nice futuristic-alien sort of thing, good for signage aboard a spaceship or other kind of project. If you enjoy this font, visit the Temphis Runes page and download the freeware sampler of that, too (which includes another free font, a patchwork frankenstein of the entire family).

This font is copyright 2001 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind. Contact me at sjohn@cumberlandgames.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0
