TEMPHIS BRICK
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Temphis Brick is the third in a series of limited-release variants for the Temphis Runes (after Temphis Sweatermonkey and Temphis Knotwork). Sorry I got this up so late this month; I had a nasty flu kicking my butt for the past week and change.

This font is copyright 2003 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind. Contact me at sjohn@cumberlandgames.com if you're interested in a licence for public or organizational use.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0
