TEMPHIS KNOTWORK
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

The Temphis Runes is an ongoing hobby for me, these days; the idea is that I'll eventually have dozens and dozens of styles available for a single fantasy cypherbet.

This particular variant, Temphis Knotwork, is a rough draft of a celticky take on it, tongue in cheek. I hand-doodled the masters over giant printouts of Temphis Scrivener, modifying as I went. If you're a Uresia or Temphis Runes fan, add it to your collection ... If you're new to both, snag it and put it to whatever use you enjoy!

This font is copyright 2003 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind. Contact me at sjohn@cumberlandgames.com if you're interested in a licence for public or organizational use.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0
