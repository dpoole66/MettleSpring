TEMPHIS DIRTY
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

It�s hard for anything in Uresia to really be anachronistic (it�s a fantasy world where children have hand-held videogames), but this playful free expansion to the Temphis Runes comes close. It�s called Temphis Dirty because it�s stressed and blotted to evoke a sense of worn-out newsprint (much like one of my old standards, Dirty Headline). Like its sister fonts, Temphis Dirty is a caps-and-numerals set with limited punctuation (but that�s all the punctuation they have in Temphis, where they have more colorful fish to fry). Enjoy!

This font is copyright 2005 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for private, non-commercial use.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0
